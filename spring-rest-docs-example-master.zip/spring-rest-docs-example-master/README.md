# Rest Docs Starter
Example repository for Spring Rest Docs blog post.